# ID успешной посылки 81342817
import sys

def read_input():
    length = int(input())
    arr = list(map(int, sys.stdin.readline().strip().split()))
    return length, arr

def main():
    length, arr = read_input()
    result = [0]*length
    distance = length
    for i in range(length):
        distance = 0 if arr[i] == 0 else distance + 1
        result[i] = distance
    distance = length
    for i in reversed(range(length)):
        distance = 0 if arr[i] == 0 else distance + 1
        if distance < result[i]:
            result[i] = distance

    print(" ".join(map(str, result)))

if __name__ == '__main__':
    main()
